package com.spring.securityInAction.ch02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch02Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch02Application.class, args);
	}

}
